/*
Copyright © 2024 NAME HERE <EMAIL ADDRESS>
*/
package main

import (
	"github.com/scraly/prog-mag-cli-go/cmd"
)

func main() {
	cmd.Execute()
}
