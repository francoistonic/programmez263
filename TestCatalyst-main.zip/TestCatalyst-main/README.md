# Projet C# TestCatalyst
* Project using the framework NLP C# [Catalyst](https://github.com/curiosity-ai/catalyst).
* based on the version 1.0.40904 (DotNet 7.0), [Nuget](https://www.nuget.org/packages/Catalyst).

Three applications:
* NER in French,
* LDA in English,
* Language detection.
